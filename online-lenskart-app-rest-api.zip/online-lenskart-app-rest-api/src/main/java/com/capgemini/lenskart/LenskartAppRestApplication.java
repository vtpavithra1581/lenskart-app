package com.capgemini.lenskart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LenskartAppRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LenskartAppRestApplication.class, args);
	}

}
