package com.capgemini.lenskart.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.lenskart.dto.AdminDTO;
import com.capgemini.lenskart.entity.Admin;
import com.capgemini.lenskart.entity.User;
import com.capgemini.lenskart.repository.AdminRepository;
import com.capgemini.lenskart.repository.UserRepository;
import com.capgemini.lenskart.service.AdminService;




@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminRepository repository;
	@Autowired 
	private UserRepository userRepository;

	@Override
	public AdminDTO saveAdmin(AdminDTO adminDTO) {
		User user=new User();
        user.setPassword(adminDTO.getPassword());
        user.setRole("ADMIN");
      user.setUserName(adminDTO.getUserName());
        User userSave=userRepository.save(user);


        Admin admin = new Admin();
        admin.setUser(userSave);
        admin.setEmail(adminDTO.getEmail());
        admin.setPassword(adminDTO.getPassword());
        Admin saveId=repository.save(admin);
        adminDTO.setId(saveId.getId());
                return adminDTO;
		
	}

	@Override
	public AdminDTO updateAdmin(AdminDTO adminDTO) {
		//Convert the DTO in the Entity object
		Admin admin=new Admin(); //Empty Entity Object
		BeanUtils.copyProperties(adminDTO, admin);
		repository.save(admin);
		return adminDTO;
	
	}

	@Override
	public boolean deleteAdmin(AdminDTO adminDTO) {
		//Convert the DTO in the Entity object
		Admin admin=new Admin(); //Empty Entity Object
		BeanUtils.copyProperties(adminDTO, admin);
		repository.delete(admin);
		return true;
	}

	@Override
	public AdminDTO getById(int id) {
		Optional<Admin> admin=repository.findById(id);
		if(admin.isPresent()) {
			//Convert the entity to DTO
			AdminDTO dto=new AdminDTO();
			BeanUtils.copyProperties(admin.get(), dto);
			return dto;
		}
	return null;
		
	}
	
}
