package com.capgemini.lenskart.exception;

public class FrameNotFoundException extends RuntimeException{

	public FrameNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FrameNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}