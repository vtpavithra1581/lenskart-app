package com.capgemini.lenskart.exception;

public class SunGlassesNotFoundException extends RuntimeException{

	public SunGlassesNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SunGlassesNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}