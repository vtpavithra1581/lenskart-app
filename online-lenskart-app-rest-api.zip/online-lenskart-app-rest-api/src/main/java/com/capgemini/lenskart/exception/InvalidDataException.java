package com.capgemini.lenskart.exception;

public class InvalidDataException extends RuntimeException {

	public InvalidDataException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidDataException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}