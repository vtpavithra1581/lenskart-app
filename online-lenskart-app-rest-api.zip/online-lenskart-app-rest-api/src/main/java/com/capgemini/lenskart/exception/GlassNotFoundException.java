package com.capgemini.lenskart.exception;

public class GlassNotFoundException extends RuntimeException{

	public GlassNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GlassNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}