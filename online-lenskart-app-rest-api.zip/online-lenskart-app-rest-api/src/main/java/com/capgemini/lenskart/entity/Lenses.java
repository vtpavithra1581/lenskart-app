package com.capgemini.lenskart.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="lenses")
public class Lenses extends Product{
	private int glassId;
	private String brand;
	private String image;
	private String shape;
	private String color;
	private  int  quantity;
	
	
	public int getGlassId() {
		return glassId;
	}
	public void setGlassId(int glassId) {
		this.glassId = glassId;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getShape() {
		return shape;
	}
	public void setShape(String shape) {
		this.shape = shape;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
