package com.capgemini.lenskart.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.lenskart.entity.SunGlasses;




@Repository
public interface SunGlassesRepository extends CrudRepository<SunGlasses,Integer>{

	//List<SunGlasses> findByCustomerId(int id);

}
