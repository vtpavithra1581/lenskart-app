package com.capgemini.lenskart.exception;

public class LensesNotFoundException extends RuntimeException{

	public LensesNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LensesNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}