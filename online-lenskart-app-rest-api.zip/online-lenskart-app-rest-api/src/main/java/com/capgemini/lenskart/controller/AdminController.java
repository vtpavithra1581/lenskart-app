package com.capgemini.lenskart.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.lenskart.dto.AdminDTO;
import com.capgemini.lenskart.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	//http://localhost:1581/api/admin
	@PostMapping
	public ResponseEntity<AdminDTO> saveAdmin(@Valid @RequestBody AdminDTO adminDTO){
		return ResponseEntity.ok(adminService.saveAdmin(adminDTO));
	
	}
	
	//http://localhost:1581/api/admin/1
	 @DeleteMapping("/{id}")
	    public ResponseEntity<?> deleteUser(@PathVariable int id) {
	       AdminDTO dto = adminService.getById(id);
	        if (dto != null) {
	            return new ResponseEntity<Boolean>(adminService.deleteAdmin(dto), HttpStatus.OK);
	        }
	        return new ResponseEntity<String>("The Admin id " + id + " does not exists", HttpStatus.NOT_FOUND);
	    }
	 
	//http://localhost:1581/api/admin
	 @PutMapping
	    public ResponseEntity<AdminDTO> updateAdmin(@RequestBody AdminDTO dto) {
	        return new ResponseEntity<AdminDTO>(adminService.updateAdmin(dto), HttpStatus.ACCEPTED);
	    }
}
