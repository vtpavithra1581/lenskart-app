package com.capgemini.lenskart.service;

import com.capgemini.lenskart.dto.AdminDTO;

public interface AdminService {
	
	public AdminDTO saveAdmin(AdminDTO adminDTO);
	public AdminDTO updateAdmin(AdminDTO adminDTO);
	public boolean deleteAdmin(AdminDTO adminDTO);
	public AdminDTO getById(int id);

}
