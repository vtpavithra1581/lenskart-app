package com.capgemini.lenskart.entity;


import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="glasses")
public class Glass extends Product {
    private int glassId;
	private String image;
	private String brand;
	private String type;
	private Long powerRange;
	
	
	public int getGlassId() {
		return glassId;
	}
	public void setGlassId(int glassId) {
		this.glassId = glassId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getPowerRange() {
		return powerRange;
	}
	public void setPowerRange(Long powerRange) {
		this.powerRange = powerRange;
	}
		
}
