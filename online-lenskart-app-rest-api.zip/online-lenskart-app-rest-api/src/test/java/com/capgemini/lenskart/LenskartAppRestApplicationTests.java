package com.capgemini.lenskart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LenskartAppRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
